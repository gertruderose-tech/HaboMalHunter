# 判断ELF是否是Intel 平台上可执行

# 测试
python is_exec.py file

# 使用
请使用 is_exec_intel 函数


